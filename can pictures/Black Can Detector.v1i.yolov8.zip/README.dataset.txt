# Black Can Detector > 2026-09-06 11:13am
https://universe.roboflow.com/geovani-coronado/black-can-detector

Provided by a Roboflow user
License: CC BY 4.0

